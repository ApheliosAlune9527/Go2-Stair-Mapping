string uuid
string body