#!/usr/bin/env bash
set -euo pipefail

echo "=== [7] 离线回放数据包（无需插网线，空格暂停/方向键调速） ==="

set +u
source "$HOME/unitree_ros2/setup.sh"
set -u

export CYCLONEDDS_URI='<CycloneDDS><Domain><General><Interfaces><NetworkInterface name="lo" /></Interfaces></General></Domain></CycloneDDS>'

if [ $# -ge 1 ]; then
  BAG_DIR="$1"
else
  mapfile -t BAGS < <(find "$HOME/unitree_ros2/bags" -maxdepth 2 -name "metadata.yaml" -printf "%T@ %h\n" 2>/dev/null | sort -rn | cut -d' ' -f2-)
  if [ "${#BAGS[@]}" -eq 0 ]; then
    echo "❌ ~/unitree_ros2/bags 下没有找到任何数据包。"
    exit 1
  fi
  echo "可用数据包（按修改时间从新到旧）："
  for i in "${!BAGS[@]}"; do
    sz=$(du -sh "${BAGS[$i]}" | awk '{print $1}')
    echo "  [$((i+1))] ${BAGS[$i]} ($sz)"
  done
  read -r -p "请输入编号（直接回车播放最新 [1]）: " pick
  pick="${pick:-1}"
  if ! [[ "$pick" =~ ^[0-9]+$ ]] || [ "$pick" -lt 1 ] || [ "$pick" -gt "${#BAGS[@]}" ]; then
    echo "❌ 无效编号: $pick"
    exit 1
  fi
  BAG_DIR="${BAGS[$((pick-1))]}"
fi

echo "正在回放：$BAG_DIR"
exec ros2 bag play "$BAG_DIR" --rate 1.0
