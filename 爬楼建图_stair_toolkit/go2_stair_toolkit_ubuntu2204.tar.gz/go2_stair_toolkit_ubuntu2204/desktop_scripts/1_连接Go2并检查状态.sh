#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HOME/Go2/go2_nic.sh"

echo "=== [1] 连接 Go2 有线网卡并检查状态 ==="
if [ $# -ge 1 ]; then
  GO2_NIC="$1"
else
  GO2_NIC="$(resolve_go2_nic || true)"
fi

if [ -z "$GO2_NIC" ] || [ ! -e "/sys/class/net/$GO2_NIC" ]; then
  echo "❌ 未检测到可用的有线网卡。可用有线网卡如下："
  list_ethernet_nics || true
  echo "请插好网线或手动指定网卡：GO2_IFACE=<网卡名> $0"
  exit 1
fi

echo "使用有线网卡：$GO2_NIC"

if command -v nmcli >/dev/null 2>&1; then
  if nmcli connection show "Unitree-Go2" >/dev/null 2>&1; then
    cur_if="$(nmcli -g connection.interface-name connection show "Unitree-Go2" 2>/dev/null || true)"
    if [ "$cur_if" != "$GO2_NIC" ]; then
      sudo nmcli connection modify "Unitree-Go2" \
        connection.interface-name "$GO2_NIC" \
        ipv4.method manual \
        ipv4.addresses 192.168.123.99/24 \
        ipv6.method disabled \
        connection.autoconnect no
    fi
  else
    echo "首次创建 NetworkManager 连接配置 Unitree-Go2 (192.168.123.99/24)..."
    sudo nmcli connection add type ethernet \
      ifname "$GO2_NIC" \
      con-name "Unitree-Go2" \
      ipv4.method manual \
      ipv4.addresses 192.168.123.99/24 \
      ipv6.method disabled \
      connection.autoconnect no
  fi
  sudo nmcli connection up "Unitree-Go2" ifname "$GO2_NIC"
else
  echo "⚠️  未安装 nmcli，改用 ip 命令临时配置 192.168.123.99/24 ..."
  sudo ip link set "$GO2_NIC" up
  sudo ip addr replace 192.168.123.99/24 dev "$GO2_NIC"
fi

write_unitree_setup_sh "$GO2_NIC"

echo
echo "网卡状态："
ip -brief addr show "$GO2_NIC"

if ! ip -brief addr show "$GO2_NIC" | grep -q "192\.168\.123\."; then
  echo "❌ $GO2_NIC 未获取到 192.168.123.x IP，请检查网线是否插紧、Go2 是否已开机。"
  exit 1
fi

pkill -f "ros2-daemon" 2>/dev/null || true

set +u
source "$HOME/unitree_ros2/setup.sh"
set -u

echo
echo "正在检查机器狗在线话题（约需 2~3 秒）..."
for topic in /utlidar/cloud_deskewed /utlidar/robot_odom /sportmodestate /api/videohub/response; do
  pub_cnt=$(timeout 4 ros2 topic info --no-daemon "$topic" 2>/dev/null | awk '/Publisher count:/{print $3}' || echo "0")
  pub_cnt="${pub_cnt:-0}"
  if [ "$pub_cnt" -ge 1 ] 2>/dev/null; then
    echo "  ✅ $topic (Publisher count: $pub_cnt)"
  else
    echo "  ⚠️  $topic (Publisher count: $pub_cnt) -- 若刚开机请等几秒重试"
  fi
done

echo
echo "操作提醒："
echo "  1. 下一步请新开终端运行：$SCRIPT_DIR/2_开启机头相机桥接.sh"
echo "  2. 遥控爬楼时尽量只推摇杆控制走动/转向，避免按实体按键触发 USLAM 急停。"
