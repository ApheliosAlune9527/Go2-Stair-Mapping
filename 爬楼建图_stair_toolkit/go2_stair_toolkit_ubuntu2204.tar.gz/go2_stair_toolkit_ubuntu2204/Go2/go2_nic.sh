#!/usr/bin/env bash
# Helper functions to resolve and configure the wired Ethernet NIC for Unitree Go2.

list_ethernet_nics() {
  local nics=()
  if command -v nmcli >/dev/null 2>&1; then
    while IFS= read -r dev; do
      [ -n "$dev" ] && nics+=("$dev")
    done < <(nmcli -t -f DEVICE,TYPE device status 2>/dev/null | awk -F: '$2=="ethernet" && $1!="" {print $1}')
  fi
  if [ "${#nics[@]}" -eq 0 ]; then
    local p b
    for p in /sys/class/net/*; do
      b="$(basename "$p")"
      case "$b" in
        lo|wl*|ww*|docker*|br-*|veth*|virbr*|tun*|tap*) continue ;;
      esac
      [ -n "$b" ] && nics+=("$b")
    done
  fi
  printf '%s\n' "${nics[@]}"
}

resolve_go2_nic() {
  local cand=""
  if [ -n "${GO2_IFACE:-}" ] && [ -e "/sys/class/net/$GO2_IFACE" ]; then
    echo "$GO2_IFACE"
    return 0
  fi

  cand="$(ip -o -4 addr show 2>/dev/null | awk '$4 ~ /^192\.168\.123\./ && $2 != "lo" {print $2; exit}')"
  if [ -n "$cand" ] && [ -e "/sys/class/net/$cand" ]; then
    echo "$cand"
    return 0
  fi

  if [ -f "$HOME/.config/go2_stair/nic" ]; then
    cand="$(head -n 1 "$HOME/.config/go2_stair/nic" | tr -d '[:space:]')"
    if [ -n "$cand" ] && [ -e "/sys/class/net/$cand" ]; then
      echo "$cand"
      return 0
    fi
  fi

  if [ -f "$HOME/unitree_ros2/setup.sh" ]; then
    cand="$(sed -n 's/.*NetworkInterface name="\([^"]*\)".*/\1/p' "$HOME/unitree_ros2/setup.sh" | head -n 1)"
    if [ -n "$cand" ] && [ "$cand" != "lo" ] && [ -e "/sys/class/net/$cand" ]; then
      echo "$cand"
      return 0
    fi
  fi

  cand="$(list_ethernet_nics | head -n 1)"
  if [ -n "$cand" ]; then
    echo "$cand"
    return 0
  fi
  return 1
}

write_unitree_setup_sh() {
  local nic="$1"
  mkdir -p "$HOME/unitree_ros2"
  cat > "$HOME/unitree_ros2/setup.sh" <<EOF
#!/bin/bash
echo "Setup unitree ros2 environment"
source /opt/ros/humble/setup.bash
source \$HOME/unitree_ros2/cyclonedds_ws/install/setup.bash
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export ROS_DOMAIN_ID=0
export CYCLONEDDS_URI='<CycloneDDS><Domain><General><Interfaces>
                            <NetworkInterface name="${nic}" priority="default" multicast="default" />
                        </Interfaces></General></Domain></CycloneDDS>'
EOF
  chmod +x "$HOME/unitree_ros2/setup.sh"
  mkdir -p "$HOME/.config/go2_stair"
  printf '%s\n' "$nic" > "$HOME/.config/go2_stair/nic"
}
