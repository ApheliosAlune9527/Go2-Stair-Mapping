#!/usr/bin/env bash
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NIC_ARG=""
AUTO_YES=0
SKIP_APT=0
SKIP_NM=0

while [ $# -gt 0 ]; do
  case "$1" in
    --nic)
      NIC_ARG="${2:-}"
      shift 2
      ;;
    -y|--yes)
      AUTO_YES=1
      shift
      ;;
    --skip-apt)
      SKIP_APT=1
      shift
      ;;
    --skip-nm)
      SKIP_NM=1
      shift
      ;;
    -h|--help)
      cat <<EOF
用法：$0 [选项]
  --nic <网卡名>   直接指定连接 Go2 的有线网卡（如 enp3s0、eth0）
  -y, --yes        非交互模式（自动确认安装依赖与默认选项）
  --skip-apt       跳过 apt 依赖检查与安装
  --skip-nm        跳过创建 NetworkManager 的 Unitree-Go2 连接配置
EOF
      exit 0
      ;;
    *)
      echo "未知参数: $1"
      exit 1
      ;;
  esac
done

echo "=== Go2 爬楼梯工具包一键安装（Ubuntu 22.04 + ROS 2 Humble） ==="

if [ ! -f /opt/ros/humble/setup.bash ]; then
  echo "❌ 未检测到 /opt/ros/humble/setup.bash，请先在目标 Ubuntu 22.04 安装 ROS 2 Humble (ros-humble-desktop)。"
  echo "   参考：https://docs.ros.org/en/humble/Installation/Ubuntu-Install-Debians.html"
  exit 1
fi

APT_PKGS=(
  ros-humble-rmw-cyclonedds-cpp
  ros-humble-cyclonedds
  ros-humble-rosidl-default-generators
  ros-humble-rosidl-generator-dds-idl
  ros-humble-rosbag2
  ros-humble-rosbag2-py
  ros-humble-rosbag2-storage-default-plugins
  ros-humble-rviz2
  ros-humble-sensor-msgs-py
  python3-colcon-common-extensions
  python3-numpy
  python3-scipy
  python3-opencv
  build-essential
  cmake
  libyaml-cpp-dev
  network-manager
)

if [ "$SKIP_APT" -eq 0 ]; then
  MISSING_PKGS=()
  for pkg in "${APT_PKGS[@]}"; do
    if ! dpkg -s "$pkg" >/dev/null 2>&1; then
      MISSING_PKGS+=("$pkg")
    fi
  done
  if [ "${#MISSING_PKGS[@]}" -gt 0 ]; then
    echo "检测到以下缺失系统依赖包："
    printf '  - %s\n' "${MISSING_PKGS[@]}"
    if [ "$AUTO_YES" -eq 0 ]; then
      read -r -p "是否立即运行 sudo apt install 安装？[Y/n]: " ans
      if [[ "${ans:-Y}" =~ ^[Nn]$ ]]; then
        echo "已跳过 apt 安装；若后续报错请自行安装上述包。"
      else
        sudo apt-get update
        sudo apt-get install -y "${MISSING_PKGS[@]}"
      fi
    else
      sudo apt-get update
      sudo apt-get install -y "${MISSING_PKGS[@]}"
    fi
  else
    echo "✅ 所有系统与 ROS 2 Humble 依赖包均已安装。"
  fi
fi

echo
echo "[1/5] 部署 ~/Go2 程序与 RViz2 配置..."
mkdir -p "$HOME/Go2"
cp -f "$BUNDLE_DIR"/Go2/* "$HOME/Go2/"
chmod +x "$HOME/Go2/go2_front_cam_node.py" "$HOME/Go2/process_stair_bag.py" "$HOME/Go2/go2_nic.sh"

echo "[2/5] 部署 ~/unitree_ros2 消息源码（不覆盖已有 bags/）..."
mkdir -p "$HOME/unitree_ros2/cyclonedds_ws" "$HOME/unitree_ros2/bags"
rm -rf "$HOME/unitree_ros2/cyclonedds_ws/src"
cp -a "$BUNDLE_DIR/unitree_ros2/cyclonedds_ws/src" "$HOME/unitree_ros2/cyclonedds_ws/"
for f in CHANGELOG.md LICENSE README.md "README _zh.md" setup_default.sh setup_local.sh version.txt; do
  if [ -f "$BUNDLE_DIR/unitree_ros2/$f" ]; then
    cp -f "$BUNDLE_DIR/unitree_ros2/$f" "$HOME/unitree_ros2/"
  fi
done

echo "[3/5] 在本机编译 Unitree ROS 2 消息包（unitree_api / unitree_go / unitree_hg）..."
rm -rf "$HOME/unitree_ros2/cyclonedds_ws/build" \
       "$HOME/unitree_ros2/cyclonedds_ws/install" \
       "$HOME/unitree_ros2/cyclonedds_ws/log"
env -i PATH="$PATH" HOME="$HOME" USER="${USER:-$(id -un)}" TERM="${TERM:-xterm}" \
  bash -c 'set +u; source /opt/ros/humble/setup.bash; set -u; cd "$HOME/unitree_ros2/cyclonedds_ws" && colcon build --packages-select unitree_api unitree_go unitree_hg'

echo "[4/5] 识别有线网卡并生成 ~/unitree_ros2/setup.sh ..."
source "$HOME/Go2/go2_nic.sh"

CHOSEN_NIC="$NIC_ARG"
if [ -z "$CHOSEN_NIC" ]; then
  mapfile -t NICS < <(list_ethernet_nics || true)
  if [ "${#NICS[@]}" -eq 0 ]; then
    CHOSEN_NIC="eth0"
    echo "⚠️  暂未发现有线网卡（如果稍后接 USB 网卡也行），先默认写入 $CHOSEN_NIC；运行脚本 1 时会自动重新检测。"
  elif [ "${#NICS[@]}" -eq 1 ] || [ "$AUTO_YES" -eq 1 ]; then
    CHOSEN_NIC="${NICS[0]}"
    echo "检测到有线网卡：$CHOSEN_NIC"
  else
    echo "检测到多个有线网卡："
    for i in "${!NICS[@]}"; do
      echo "  [$((i+1))] ${NICS[$i]}"
    done
    read -r -p "请选择连接 Go2 的有线网卡编号（默认 1）: " pick
    pick="${pick:-1}"
    if [[ "$pick" =~ ^[0-9]+$ ]] && [ "$pick" -ge 1 ] && [ "$pick" -le "${#NICS[@]}" ]; then
      CHOSEN_NIC="${NICS[$((pick-1))]}"
    else
      CHOSEN_NIC="${NICS[0]}"
    fi
  fi
fi

write_unitree_setup_sh "$CHOSEN_NIC"

if [ "$SKIP_NM" -eq 0 ] && command -v nmcli >/dev/null 2>&1 && [ -e "/sys/class/net/$CHOSEN_NIC" ]; then
  create_nm=0
  if [ "$AUTO_YES" -eq 1 ]; then
    create_nm=1
  else
    read -r -p "是否为网卡 $CHOSEN_NIC 创建/更新 NetworkManager 配置 Unitree-Go2 (192.168.123.99/24)？[Y/n]: " ans
    [[ ! "${ans:-Y}" =~ ^[Nn]$ ]] && create_nm=1
  fi
  if [ "$create_nm" -eq 1 ]; then
    if nmcli connection show "Unitree-Go2" >/dev/null 2>&1; then
      sudo nmcli connection modify "Unitree-Go2" \
        connection.interface-name "$CHOSEN_NIC" \
        ipv4.method manual \
        ipv4.addresses 192.168.123.99/24 \
        ipv6.method disabled \
        connection.autoconnect no
    else
      sudo nmcli connection add type ethernet \
        ifname "$CHOSEN_NIC" \
        con-name "Unitree-Go2" \
        ipv4.method manual \
        ipv4.addresses 192.168.123.99/24 \
        ipv6.method disabled \
        connection.autoconnect no
    fi
    echo "✅ 已配置 Unitree-Go2 -> $CHOSEN_NIC (192.168.123.99/24)"
  fi
fi

echo "[5/5] 安装 7 个启动脚本到桌面..."
DESKTOP_DIR=""
if command -v xdg-user-dir >/dev/null 2>&1; then
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
fi
if [ -z "$DESKTOP_DIR" ] || [ "$DESKTOP_DIR" = "$HOME" ]; then
  if [ -d "$HOME/桌面" ]; then
    DESKTOP_DIR="$HOME/桌面"
  else
    DESKTOP_DIR="$HOME/Desktop"
  fi
fi
mkdir -p "$DESKTOP_DIR"
cp -f "$BUNDLE_DIR"/desktop_scripts/*.sh "$DESKTOP_DIR/"
cp -f "$BUNDLE_DIR/使用说明.md" "$DESKTOP_DIR/Go2使用说明.md"
chmod +x "$DESKTOP_DIR"/[1-7]_*.sh

echo
echo "=== 安装自检 ==="
set +u
source "$HOME/unitree_ros2/setup.sh" >/dev/null
set -u
python3 - <<'EOF'
import numpy, scipy, cv2, rclpy, rosbag2_py, unitree_go, unitree_api
print("Python 模块导入自检全部通过 ✅")
EOF
python3 "$HOME/Go2/process_stair_bag.py" --help >/dev/null

echo
echo "🎉 安装完成！"
echo "  脚本目录：$DESKTOP_DIR"
echo "  程序目录：$HOME/Go2"
echo "  ROS2工作区：$HOME/unitree_ros2"
echo "  默认网卡：$CHOSEN_NIC（插网线后运行 $DESKTOP_DIR/1_连接Go2并检查状态.sh 即可自动适配）"
